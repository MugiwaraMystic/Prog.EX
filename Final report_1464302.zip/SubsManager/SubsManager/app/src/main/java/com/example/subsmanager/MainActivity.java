package com.example.subsmanager;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;
import android.app.AlertDialog;

import android.view.LayoutInflater;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.IOException;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private static final int ADD_SUBSCRIPTION_REQUEST = 1;
    private RecyclerView recyclerView;
    private FloatingActionButton fab;
    private SharedPreferences sharedPreferences;
    private SubscriptionAdapter subscriptionAdapter;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sharedPreferences = getSharedPreferences("MyAppPrefs", MODE_PRIVATE);
        String token = sharedPreferences.getString("token", null);
        userId = sharedPreferences.getInt("userId", -1);

        if (token == null || userId == -1) {
            // User is not logged in, redirect to LoginActivity
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            finish();
            return;
        }

        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        fab = findViewById(R.id.fab);
        fab.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddSubscriptionActivity.class);
            startActivityForResult(intent, ADD_SUBSCRIPTION_REQUEST);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        loadSubscriptions();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.action_sign_out) {
            signOut();
            return true;
        } else if (itemId == R.id.action_about_us) {
            showInfoDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void signOut() {
        // Clear shared preferences
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("token");
        editor.remove("userId");
        editor.apply();

        // Redirect to login activity
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        finish();

        Toast.makeText(this, "Signed out successfully", Toast.LENGTH_SHORT).show();
    }

    private void showInfoDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_info, null);
        builder.setView(dialogView);

        TextView infoTextView = dialogView.findViewById(R.id.infoTextView);
        Button exitButton = dialogView.findViewById(R.id.exitButton);

        infoTextView.setText("Welcome to SubsManager! SubsManager is your ultimate solution for managing all your subscriptions in one place. Whether it's your favorite streaming services, magazines, or any other recurring payments, SubsManager helps you keep track of them effortlessly. Features: - **Add and Manage Subscriptions:** Easily add new subscriptions with details like name, price, subscription type, and next payment date. Manage them with a few taps. - **Renew Subscriptions:** Quickly renew your subscriptions based on their type (monthly or yearly) with our convenient renew feature. - **Delete Subscriptions:** Remove subscriptions you no longer need with a simple click. - **Notifications:** Stay on top of your payments with timely notifications before any subscription is due. Our goal is to simplify your life by providing an easy-to-use interface that consolidates all your subscription information. No more missed payments or forgotten subscriptions. With SubsManager, everything is organized and accessible. Thank you for choosing SubsManager. We hope it brings convenience and efficiency to your daily life. For any feedback or support, feel free to contact us at support@subsmanager.com. Happy Managing! The SubsManager Team");

        AlertDialog dialog = builder.create();

        exitButton.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_SUBSCRIPTION_REQUEST && resultCode == RESULT_OK) {
            // Reload subscriptions after adding a new one
            loadSubscriptions();
        }
    }

    private void loadSubscriptions() {
        Retrofit retrofit = RetrofitClient.getRetrofitInstance();
        ApiService apiService = retrofit.create(ApiService.class);

        Call<List<UserSubscription>> call = apiService.getSubscriptions(new UserIdRequest(userId));
        call.enqueue(new Callback<List<UserSubscription>>() {
            @Override
            public void onResponse(Call<List<UserSubscription>> call, Response<List<UserSubscription>> response) {
                if (response.isSuccessful()) {
                    List<UserSubscription> subscriptions = response.body();
                    subscriptionAdapter = new SubscriptionAdapter(subscriptions, new SubscriptionAdapter.OnItemClickListener() {
                        @Override
                        public void onDeleteClick(int subscriptionId) {
                            Log.d(TAG, "Attempting to delete subscription with ID: " + subscriptionId);
                            deleteSubscription(subscriptionId);
                        }

                        @Override
                        public void onRenewClick(int subscriptionId) {
                            Log.d(TAG, "Attempting to renew subscription with ID: " + subscriptionId);
                            renewSubscription(subscriptionId);
                        }
                    });
                    recyclerView.setAdapter(subscriptionAdapter);
                } else {
                    try {
                        String errorBody = response.errorBody().string();
                        Log.e(TAG, "Response error: " + errorBody);
                        Toast.makeText(MainActivity.this, "Failed to load subscriptions: " + errorBody, Toast.LENGTH_SHORT).show();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Toast.makeText(MainActivity.this, "Failed to read error response", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<List<UserSubscription>> call, Throwable t) {
                Log.e(TAG, "Network error: " + t.getMessage());
                Toast.makeText(MainActivity.this, "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void deleteSubscription(int subscriptionId) {
        Retrofit retrofit = RetrofitClient.getRetrofitInstance();
        ApiService apiService = retrofit.create(ApiService.class);

        Log.d(TAG, "Deleting subscription with ID: " + subscriptionId + " for user ID: " + userId); // Log IDs

        Call<Void> call = apiService.deleteSubscription(new DeleteSubscriptionRequest(userId, subscriptionId));
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(MainActivity.this, "Subscription deleted successfully", Toast.LENGTH_SHORT).show();
                    loadSubscriptions(); // Reload subscriptions after deletion
                } else {
                    try {
                        String errorBody = response.errorBody().string();
                        Log.e(TAG, "Response error: " + errorBody);
                        Toast.makeText(MainActivity.this, "Failed to delete subscription: " + errorBody, Toast.LENGTH_SHORT).show();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Toast.makeText(MainActivity.this, "Failed to read error response", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Log.e(TAG, "Network error: " + t.getMessage());
                Toast.makeText(MainActivity.this, "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void renewSubscription(int subscriptionId) {
        Retrofit retrofit = RetrofitClient.getRetrofitInstance();
        ApiService apiService = retrofit.create(ApiService.class);

        Log.d(TAG, "Renewing subscription with ID: " + subscriptionId + " for user ID: " + userId); // Log IDs

        Call<Void> call = apiService.renewSubscription(new RenewSubscriptionRequest(subscriptionId));
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(MainActivity.this, "Subscription renewed successfully", Toast.LENGTH_SHORT).show();
                    loadSubscriptions(); // Reload subscriptions after renewal
                } else {
                    try {
                        String errorBody = response.errorBody().string();
                        Log.e(TAG, "Response error: " + errorBody);
                        Toast.makeText(MainActivity.this, "Failed to renew subscription: " + errorBody, Toast.LENGTH_SHORT).show();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Toast.makeText(MainActivity.this, "Failed to read error response", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Log.e(TAG, "Network error: " + t.getMessage());
                Toast.makeText(MainActivity.this, "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
