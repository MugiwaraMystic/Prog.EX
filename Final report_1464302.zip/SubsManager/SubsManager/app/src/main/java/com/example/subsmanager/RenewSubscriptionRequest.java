package com.example.subsmanager;

public class RenewSubscriptionRequest {
    private int subscriptionId;

    public RenewSubscriptionRequest(int subscriptionId) {
        this.subscriptionId = subscriptionId;
    }

    public int getSubscriptionId() {
        return subscriptionId;
    }
}
