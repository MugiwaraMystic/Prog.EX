package com.example.subsmanager;

public class UserLoginResponse {
    private String status;
    private String message;
    private int userId;

    public UserLoginResponse(String status, String message, int userId) {
        this.status = status;
        this.message = message;
        this.userId = userId;
    }

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public int getUserId() {
        return userId;
    }
}
