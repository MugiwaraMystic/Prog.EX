package com.example.subsmanager;

public class UserIdRequest {
    private int userId;

    public UserIdRequest(int userId) {
        this.userId = userId;
    }

    public int getUserId() {
        return userId;
    }
}
