package com.example.subsmanager;

public class LoginResponse {
    private String status;
    private String message;
    private int userId;

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public int getUserId() {
        return userId;
    }
}
