package com.example.subsmanager;

public class UserSubscription {
    private int id;
    private int userId;
    private String name;
    private String price;
    private String SubscriptionType;
    private String next_payment;

    public UserSubscription(int id, int userId, String name, String price, String SubscriptionType, String next_payment) {
        this.id = id;
        this.userId = userId;
        this.name = name;
        this.price = price;
        this.SubscriptionType = SubscriptionType;
        this.next_payment = next_payment;
    }

    public int getId() {
        return id;
    }

    public int getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public String getPrice() {
        return price;
    }

    public String getSubscriptionType() {
        return SubscriptionType;
    }

    public String getNextPayment() {
        return next_payment;
    }

    @Override
    public String toString() {
        return "UserSubscription{" +
                "id=" + id +
                ", userId=" + userId +
                ", name='" + name + '\'' +
                ", price='" + price + '\'' +
                ", SubscriptionType='" + SubscriptionType + '\'' +
                ", next_payment='" + next_payment + '\'' +
                '}';
    }
}
