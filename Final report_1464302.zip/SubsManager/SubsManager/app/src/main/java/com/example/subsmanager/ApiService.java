package com.example.subsmanager;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ApiService {
    @POST("getSubscriptions.php")
    Call<List<UserSubscription>> getSubscriptions(@Body UserIdRequest userIdRequest);

    @POST("deleteSubscription.php")
    Call<Void> deleteSubscription(@Body DeleteSubscriptionRequest request);

    @POST("addSubscription.php")
    Call<Void> addSubscription(@Body UserSubscription userSubscription);

    @POST("register.php")
    Call<UserLoginResponse> register(@Body User user);

    @POST("login.php")
    Call<UserLoginResponse> login(@Body User user);
    @POST("renewSubscription.php")
    Call<Void> renewSubscription(@Body RenewSubscriptionRequest request);
}
