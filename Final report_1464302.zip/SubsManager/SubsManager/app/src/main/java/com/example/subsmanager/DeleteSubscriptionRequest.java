package com.example.subsmanager;

public class DeleteSubscriptionRequest {
    private int userId;
    private int subscriptionId;

    public DeleteSubscriptionRequest(int userId, int subscriptionId) {
        this.userId = userId;
        this.subscriptionId = subscriptionId;
    }

    public int getUserId() {
        return userId;
    }

    public int getSubscriptionId() {
        return subscriptionId;
    }
}
