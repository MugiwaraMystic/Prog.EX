package com.example.subsmanager;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class AddSubscriptionActivity extends AppCompatActivity {

    private static final String TAG = "AddSubscriptionActivity";

    private EditText nameEditText, priceEditText, nextPaymentEditText;
    private RadioGroup periodRadioGroup;
    private Button saveButton;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_subscription);

        // Retrieve userId from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("MyAppPrefs", MODE_PRIVATE);
        userId = sharedPreferences.getInt("userId", -1);
        Log.d(TAG, "UserId: " + userId);

        nameEditText = findViewById(R.id.name);
        priceEditText = findViewById(R.id.price);
        nextPaymentEditText = findViewById(R.id.nextPayment);
        periodRadioGroup = findViewById(R.id.periodGroup);
        saveButton = findViewById(R.id.saveButton);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSubscription();
            }
        });
    }

    private void saveSubscription() {
        String name = nameEditText.getText().toString();
        String price = priceEditText.getText().toString();
        String subscriptionType = ((RadioButton) findViewById(periodRadioGroup.getCheckedRadioButtonId())).getText().toString();
        String nextPayment = nextPaymentEditText.getText().toString();

        Retrofit retrofit = RetrofitClient.getRetrofitInstance();
        ApiService apiService = retrofit.create(ApiService.class);

        UserSubscription userSubscription = new UserSubscription(0, userId, name, price, subscriptionType, nextPayment);
        Log.d(TAG, "Subscription Data: " + userSubscription.toString());

        Call<Void> call = apiService.addSubscription(userSubscription);
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(AddSubscriptionActivity.this, "Subscription added successfully", Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK); // Set result code to indicate success
                    finish(); // Close the activity
                    overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
                } else {
                    try {
                        String errorBody = response.errorBody().string();
                        Log.e(TAG, "Response error: " + errorBody);
                        Toast.makeText(AddSubscriptionActivity.this, "Failed to add subscription: " + errorBody, Toast.LENGTH_SHORT).show();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Toast.makeText(AddSubscriptionActivity.this, "Failed to read error response", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Log.e(TAG, "Network error: " + t.getMessage());
                Toast.makeText(AddSubscriptionActivity.this, "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
