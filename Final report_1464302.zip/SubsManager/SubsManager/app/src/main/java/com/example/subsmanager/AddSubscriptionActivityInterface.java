package com.example.subsmanager;

public interface AddSubscriptionActivityInterface {
}
