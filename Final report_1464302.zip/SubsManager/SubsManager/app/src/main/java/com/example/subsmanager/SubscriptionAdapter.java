package com.example.subsmanager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SubscriptionAdapter extends RecyclerView.Adapter<SubscriptionAdapter.SubscriptionViewHolder> {

    private List<UserSubscription> subscriptionList;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onDeleteClick(int subscriptionId);
        void onRenewClick(int subscriptionId);
    }

    public SubscriptionAdapter(List<UserSubscription> subscriptionList, OnItemClickListener listener) {
        this.subscriptionList = subscriptionList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public SubscriptionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_subscription, parent, false);
        return new SubscriptionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SubscriptionViewHolder holder, int position) {
        UserSubscription subscription = subscriptionList.get(position);
        holder.nameTextView.setText(subscription.getName());
        holder.priceTextView.setText(subscription.getPrice());
        holder.subscriptionTypeTextView.setText(subscription.getSubscriptionType());
        holder.nextPaymentTextView.setText(subscription.getNextPayment());

        holder.deleteButton.setOnClickListener(v -> listener.onDeleteClick(subscription.getId()));
        holder.renewButton.setOnClickListener(v -> listener.onRenewClick(subscription.getId()));
    }

    @Override
    public int getItemCount() {
        return subscriptionList.size();
    }

    static class SubscriptionViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView;
        TextView priceTextView;
        TextView subscriptionTypeTextView;
        TextView nextPaymentTextView;
        Button deleteButton;
        Button renewButton;

        SubscriptionViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.nameTextView);
            priceTextView = itemView.findViewById(R.id.priceTextView);
            subscriptionTypeTextView = itemView.findViewById(R.id.subscriptionTypeTextView);
            nextPaymentTextView = itemView.findViewById(R.id.nextPaymentTextView);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            renewButton = itemView.findViewById(R.id.renewButton);

        }
    }
}
